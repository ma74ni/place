<?php
print('
    </main>
    <footer>
        <div class="info p-y-60">
            <div class="container">
                <div class="row">
                    <div class="col-4">
                        <a href="home"><img class="w-120" src="./public/img/conito.png" alt=""></a>
                    </div>
                    <div class="col-4"></div>
                    <div class="col-4"></div>
                </div>
            </div>
        </div>
    </footer>
    <script src="https://code.jquery.com/jquery-3.4.1.min.js" integrity="" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
    <script src="./public/js/bootstrap.min.js" integrity="" crossorigin="anonymous"></script>
    <script src="./public/js/main.js"></script>
</body>
</html>
');
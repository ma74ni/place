<?php
print('
    <h2 class="p1  error">Error 401: NO TIENES AUTORIZACIÓN PARA ESTE RECURSO</h2>
    <img class="p1  img-404" src="./public/img/not-found.png" alt="Error 404">
    <input type="button" class="button  add  block  mauto" value="Regresar" onclick="history.back()">
');